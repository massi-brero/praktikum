package q8388415.brero_massimiliano.PTNetEditor.types;

/**
 * Suffix of types the application can read or store to. Feel free to expand.
 * 
 * @author q8388415 - Massimiliano Brero
 *
 */
public enum AllowedFileTypes {
    pnml;
}
