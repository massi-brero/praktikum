package q8388415.brero_massimiliano.PTNetEditor.types;

/**
 * This type makes it easy to identify the different node types.
 * 
 * @author q8388415 - Massimiliano Brero
 *
 */
public enum PTNNodeTypes {
	STELLE, TRANSITION;
}
